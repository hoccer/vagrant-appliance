This are OLD naxsi's rule generators.
Do not use them, except if you know what you are doing.

